<!-- The following is part of our issue template, feel free to remove this if it doesn't apply -->
### Issue description

- version `#x.x.x`
- components: `name`

### Steps to reproduce issue

- ...

<!-- The following codepen can be forked to help demonstrate the issue http://codepen.io/eddywashere/pen/ZOjmkm -->
