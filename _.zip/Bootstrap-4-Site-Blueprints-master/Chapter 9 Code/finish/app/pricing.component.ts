import { Component } from '@angular/core';

@Component({
  selector: 'pricing',
  template: '<h3>Pricing</h3>'
})
export class PricingComponent { }
