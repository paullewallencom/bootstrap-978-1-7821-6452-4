import { Component } from '@angular/core';

@Component({
  selector: 'about',
  template: '<h3>About</h3>'
})
export class AboutComponent { }
