<p class="card-text"><small class="text-muted">
	Posted on <?php the_time('F j, Y') ?> by <?php the_author_posts_link(); ?>  - <?php the_category(', ') ?>
</small></p>	
