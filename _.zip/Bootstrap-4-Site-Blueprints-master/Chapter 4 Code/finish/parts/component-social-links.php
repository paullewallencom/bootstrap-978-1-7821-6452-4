<ul>
  <li><a href="https://twitter.com/bassjobsen"><i class="fa fa-twitter fa-fw fa-lg"></i></a></li> 
  <li><a href="https://facebook.com/bassjobsen"><i class="fa fa-facebook fa-fw fa-lg"></i></a></li>
  <li><a href="http://google.com/+bassjobsen"><i class="fa fa-google-plus fa-fw fa-lg"></i></a></li>
</ul>
